import { ContientPipe } from './contient.pipe';

describe('ContientPipe', () => {
  it('create an instance', () => {
    const pipe = new ContientPipe();
    expect(pipe).toBeTruthy();
  });
});
