import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'contient'
})
export class ContientPipe implements PipeTransform {
 x:string;
 

  transform(value: any[], args: string): any {
    console.log(value);
    return value.filter(x=>x.title.search(args)>-1)
  }

}
