import { Directive,Renderer2,ElementRef, Renderer, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appMydirective]'
})
export class MydirectiveDirective {

  @Input()
  col:string;
  default_color:string="blue";
  constructor(private ele:ElementRef,private rendu:Renderer2) {
    this.rendu.setStyle(this.ele.nativeElement,"color","red");
    //this.rendu.setStyle(this.ele.nativeElement,"transform","scale(0.5,0.5)");
    

   }

   @HostListener('mouseenter',['$event']) 
   onmouseenter(event:Event){
    this.rendu.setStyle(this.ele.nativeElement,"color",this.col);
    console.log(event);
    console.log(this.ele.nativeElement);

   }

   @HostListener('mouseleave',['$event']) 
   onmousleave(event:Event){
    this.rendu.setStyle(this.ele.nativeElement,"color",this.default_color);
    console.log(event);
    console.log(this.ele);

   }
}
