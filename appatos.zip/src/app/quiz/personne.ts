export interface personne{

    nom:string;
    age:number;
    email?:string;
    [x:string] :any
    
}