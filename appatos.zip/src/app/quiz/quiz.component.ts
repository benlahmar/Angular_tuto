import { Component, OnInit,OnChanges,SimpleChanges } from '@angular/core';
import { personne } from 'src/app/quiz/personne';
import { mydata } from 'src/app/mydata/data';
import { Quiz } from '../model/quiz';
import { qst } from '../model/questionconst';
import { ActivatedRoute } from '@angular/router';
import { qst2 } from '../model/csharp';
import { HttpEventType } from '@angular/common/http';
import { Question } from '../model';


@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  mode:string='quiz';
  receptx;
   quiz:Quiz;
   step=0;
  slug:string;
  debut:Date=new Date();
  constructor(private xx:ActivatedRoute) {
    setInterval(() => {
      this.debut = new Date();
    }, 1);

   }

  goTo(n)
  {  
    this.mode='quiz';
    this.step=n;  
    
  }
  
  ngOnInit() {
    this.xx.paramMap.subscribe(param=>this.slug=param.get('abc'));
    console.log(this.slug);
    if(this.slug=='aspnet')
    this.quiz=new Quiz(qst);
    else
    this.quiz=new Quiz(qst2);
    sessionStorage.setItem('q',JSON.stringify(qst));
    
  }
    
  
    //console.log(this.quiz);
  
  abcd(event)
  {
    this.receptx=event.valx+"   ,  "+event.idx;
    console.log(event.valx+"  ,  "+event.idx);
    
  }

  review(md)
  {
    
    this.mode=md;
  }

  reviser(v:Question)
  {
    this.quiz.questions.
    forEach(x=>{let os= x.options.filter(o=>o.selected);if(os.length>0) x.answered=true;});



    if(v.answered) return 'answered';
    else
    return 'not-answered';
  }

  submit()
  {
    this.mode='submit';
    let ss=this.quiz.questions
    .forEach(x=>{let e=x.options.every(o=>o.isAnswer==o.selected);if(e) x.isCorrect=true; });
    

    
  }
aa(v:Question)
{
  if(v.isCorrect) return 'answered';
    else
    return 'not-answered';
}
}
