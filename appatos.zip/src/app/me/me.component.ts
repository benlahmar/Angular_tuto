import { Component, OnInit } from '@angular/core';
import { CrudService } from '../services/crud.service';
import { async } from 'q';
import { observable, Observable } from 'rxjs';

@Component({
  selector: 'app-me',
  templateUrl: './me.component.html',
  styleUrls: ['./me.component.css'],
  providers:[]
})
export class MeComponent implements OnInit {
rr;
  x:number=0;
  constructor(private service:CrudService) {
    
   }

  ngOnInit( ) {
    this.x= this.service.somme(5,6);
   this.aba();
   console.log("apreeeeeeees");
  }

  async aba() {
    let aa:Observable<object>=this.service.getdata();
   
    // aa.subscribe(()=>{})
     aa.subscribe((y)=>{
      this.rr=y;
      console.log(y)
     },()=>{},()=>{});
    
  }

  supp(id)
  {
    this.service.delete(id);
  }
}
