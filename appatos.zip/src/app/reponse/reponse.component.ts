import { Component, OnInit, Input } from '@angular/core';
import { Option } from '../model';

@Component({
  selector: 'app-reponse',
  templateUrl: './reponse.component.html',
  styleUrls: ['./reponse.component.css']
})
export class ReponseComponent implements OnInit {

  @Input()
  response:Option;
  constructor() { }

  ngOnInit() {
  }

  get(v:Option)
  {
    

    console.log(v);
  }
}
