import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MeRoutingModule } from './me-routing.module';
import { MeComponent } from 'src/app/me/me.component';
import { QuestionComponent } from 'src/app/question/question.component';
import { AppModule } from 'src/app/app.module';
import { CrudService } from 'src/app/services/crud.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [MeComponent],
  imports: [
    CommonModule,
    MeRoutingModule,
    HttpClientModule,
    FormsModule;
    
   
  ],
  exports:[MeComponent],
  providers:[CrudService]
})
export class MeModule { }
