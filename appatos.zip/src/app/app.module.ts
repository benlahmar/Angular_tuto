import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {  FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatexempleComponent } from './matexemple/matexemple.component';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import { MyNavComponent } from './my-nav/my-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { QuizComponent } from './quiz/quiz.component';
import { ThemesComponent } from './themes/themes.component';
import { QuestionComponent } from './question/question.component';
import { ReponseComponent } from './reponse/reponse.component';
import {Routes, RouterModule} from '@angular/router';
import { MydirectiveDirective } from './mydirective.directive'
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatBadgeModule} from '@angular/material/badge';
import { ContientPipe } from './contient.pipe';
import { ExponentialStrengthPipe } from './exponential-strength.pipe';
import { ContactModule } from './modules/lazymodule/contact/contact.module';
import { ContactComponent } from './contact/contact.component';
import { MeModule } from './modules/lezay/me/me.module';

const mesroutes:Routes=[
  {'path':'themes',component:ThemesComponent},
  {'path':'quiz',component:QuizComponent},
  {'path':'quiz/:abc',component:QuizComponent},
  {'path':'contact',loadChildren:()=>import('./modules/lazymodule/contact/contact.module').then(mod=>mod.ContactModule)},
  {'path':'abc',loadChildren:()=>
  import('./modules/lezay/me/me.module')
  .then(mod=>mod.MeModule)},
  {'path':'',component:ThemesComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    MatexempleComponent,
    MyNavComponent,
    QuizComponent,
    ThemesComponent,
    QuestionComponent,
    ReponseComponent,
    MydirectiveDirective,
    ContientPipe,
    ExponentialStrengthPipe,
    
   
  ],
  imports: [
    RouterModule.forRoot(mesroutes,{//enableTracing:true
    }),
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatButtonModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    FormsModule,
    MatBadgeModule,
    MatProgressBarModule,
    ContactModule,
    MeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }