import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
;
@Injectable({
  providedIn: 'root'
})
export class CrudService {
res;
  constructor(private http:HttpClient) { }

  somme(a:number,b:number)
  {
    return a+b;
  }
  getdata()
  {
    return this.res= this.http.get('https://jsonplaceholder.typicode.com/users');
    //console.log(this.res);
    //console.log(this.res.toPromise());
  }
  delete(id)
  {
    console.log('https://jsonplaceholder.typicode.com/users/'+id);
    return this.http.delete('https://jsonplaceholder.typicode.com/users/'+id);
  }
}
