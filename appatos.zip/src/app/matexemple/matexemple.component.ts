import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-matexemple',
  templateUrl: './matexemple.component.html',
  styleUrls: ['./matexemple.component.css']
})
export class MatexempleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}