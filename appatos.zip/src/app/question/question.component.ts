import { Component, OnInit, Input, OnChanges,SimpleChanges, Output, EventEmitter } from '@angular/core';

import {qst} from 'src/app/model/questionconst';
import { Question } from '../model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit, OnChanges {

  @Input()
  data:Question;

  @Output() notifier = new EventEmitter();
  
  constructor() { 
    
  }

  ngOnInit() {
    
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log(changes)
  }

  send(abc)
  {
    
    this.notifier.emit({'valx':this.data.id,'idx':abc});
    console.log(abc);
  }

}
